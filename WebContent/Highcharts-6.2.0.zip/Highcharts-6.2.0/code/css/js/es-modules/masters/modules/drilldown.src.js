/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * Highcharts Drilldown module
 *
 * Author: Torstein Honsi
 * License: www.highcharts.com/license
 *
 */
'use strict';
import '../../modules/drilldown.src.js';
